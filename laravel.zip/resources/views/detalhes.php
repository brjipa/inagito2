<!DOCTYPE html>
<html>
<head>
	<title>Detalhes de <?php echo $u->nome ?> </title>
</head>
<body>

<h1><?php echo $u->nome ?>;</h1>
Teste
</body>
</html>